/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import controller.KetNoiDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.naming.spi.DirStateFactory;

/**
 *
 * @author cuong
 */
public class TruyVan {
    /*
    b2:     b2.1:khoi tao doi tuong Connection va PreparedStatement
    
    */
    Connection kn =null;
   // Scanner sc=new Scanner(System.in);
    PreparedStatement ps =null;  //khoi tao doi PreparedStatedStatemnt dung de thuc thi cac cau truy van sql
    KetNoiDB knoi=new KetNoiDB();//khoi tao de gan ket noi
    // them du lieu TB
    public void themDuLieudsTB(int matb,String tentb,String xuatxu,int namsx) {
        kn=knoi.ketnoi();
        
        String sql="insert into dsthietbi(matb,tentb,xuatxu,namsx) values(?,?,?,?)";
        try {
            ps=kn.prepareStatement(sql);
            ps.setInt(1,matb);
            ps.setString(2,tentb);
            ps.setString(3,xuatxu);
            ps.setInt(4, namsx);
            //thuc thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("them data thanh cong");
            }
            else System.out.println("them du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }
        
    }
    //them du lieu Phong
    public void themDuLieudsPhong(int maP,String tenP) {
        kn=knoi.ketnoi();
        
        String sql="insert into dsphong(maP,tenP) values(?,?)";
        try {
            ps=kn.prepareStatement(sql);
            ps.setInt(1,maP);
            ps.setString(2,tenP);
            
            //thuc thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("them data thanh cong");
            }
            else System.out.println("them du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }
        
    }
    //them du lieu dsQLTB vao database
    public void themDuLieudsQLTB(int maP,int maTB,int soluong,String trangthai) {
        kn=knoi.ketnoi();
        
        String sql="insert into dsqlthietbi(maP,maTB,soluong,trangthai) values(?,?,?,?)";
        try {
            ps=kn.prepareStatement(sql);
            ps.setInt(1,maP);
            ps.setInt(2,maTB);
            ps.setInt(3,soluong);
            ps.setString(4,trangthai);
            
            //thu thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("them data thanh cong");
            }
            else System.out.println("them du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }
        
    }
    //tim kiem trong database dsTB
    public ArrayList<KetQuaTruyVan> dsTB(){
        kn=knoi.ketnoi();
        String sql="select *"
                  +"from dsthietbi";
        ArrayList<KetQuaTruyVan> listkqtvdstb=new ArrayList<>();
        try {
            ps=kn.prepareStatement(sql);
            ResultSet kq =ps.executeQuery();//b5:thuc thi sql va do du lieu truy van
       while(kq.next()==true){
       KetQuaTruyVan kqtvdstb = new KetQuaTruyVan();
            kqtvdstb.setMaTB(kq.getInt("matb"));
            kqtvdstb.setTenTB(kq.getString("tentb"));
            kqtvdstb.setXuatxu(kq.getString("xuatxu"));
            kqtvdstb.setNamsx(kq.getInt("namsx"));
            listkqtvdstb.add(kqtvdstb);
       }
        ps.close();
        kn.close();
            } catch (SQLException e) {
            System.out.println("loi"+e.getMessage());
        }
        return listkqtvdstb;
    }
    //tim kiem database danh sach phong
     public ArrayList<KetQuaTruyVan> dsP(){
        kn=knoi.ketnoi();
        String sql="select *"
                  +"from dsphong";
        ArrayList<KetQuaTruyVan> listkqtvdsphong=new ArrayList<>();
        try {
            ps=kn.prepareStatement(sql);
            ResultSet kq =ps.executeQuery();//b5:thuc thi sql va do du lieu truy van
       while(kq.next()==true){
       KetQuaTruyVan kqtvdsphong = new KetQuaTruyVan();
            kqtvdsphong.setMaP(kq.getInt("maP"));
            kqtvdsphong.setTenP(kq.getString("tenP"));
            listkqtvdsphong.add(kqtvdsphong);
       }
        ps.close();
        kn.close();
            } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }
        return listkqtvdsphong;
    }
     //tim kiem database danh sach quan ly thiet bi
      public ArrayList<KetQuaTruyVan> dsQLTB(){
        kn=knoi.ketnoi();
        String sql="select dsqlthietbi.maP,dsphong.tenP,dsqlthietbi.maTB,dsthietbi.tentb,dsqlthietbi.soluong,dsqlthietbi.trangthai"
                  +" from dsphong,dsqlthietbi,dsthietbi"
                  +" where (dsqlthietbi.maP=dsphong.maP)and(dsqlthietbi.maTB=dsthietbi.matb)";
                 
        ArrayList<KetQuaTruyVan> listkqtvdsqlTB=new ArrayList<>();
        try {
            ps=kn.prepareStatement(sql);
            ResultSet kq =ps.executeQuery();//b5:thuc thi sql va do du lieu truy van
       while(kq.next()==true){
       KetQuaTruyVan kqtvdsqlTB = new KetQuaTruyVan();
            kqtvdsqlTB.setMaP(kq.getInt("dsqlthietbi.maP"));
            kqtvdsqlTB.setTenP(kq.getString("dsphong.tenP"));
            kqtvdsqlTB.setMaTB(kq.getInt("dsqlthietbi.maTB"));
            kqtvdsqlTB.setTenTB(kq.getString("dsthietbi.tentb"));
            kqtvdsqlTB.setSoluong(kq.getInt("dsqlthietbi.soluong"));
           
            kqtvdsqlTB.setTrangthai(kq.getString("dsqlthietbi.trangthai"));
            
           
           
            listkqtvdsqlTB.add(kqtvdsqlTB);
       }
        ps.close();
        kn.close();
            } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }
        return listkqtvdsqlTB;
    }
      //xoa data dsTB
      public void XoadsTB(int maTB){
          kn=knoi.ketnoi();
        
        String sql="delete from dsthietbi where matb=?";
        try {
           ps=kn.prepareStatement(sql);
           ps.setInt(1, maTB);
            
            //thuc thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("xoa data thanh cong");
            }
            else System.out.println("xoa du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }    
      }
       public void XoadsqlTB(int maTB,int maP){
          kn=knoi.ketnoi();
        
        String sql=" delete from dsqlthietbi where (matb=?)and(maP=?)";
        try {
           ps=kn.prepareStatement(sql);
           ps.setInt(1, maTB);
           ps.setInt(2,maP);
            
            //thuc thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("xoa data thanh cong");
            }
            else System.out.println("xoa du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }    
      }
       public void XoadsP(int maP){
          kn=knoi.ketnoi();
        
        String sql="delete from dsphong where maP=?";
        try {
           ps=kn.prepareStatement(sql);
           ps.setInt(1, maP);
            
            //thuc thi sql
            int kt =ps.executeUpdate();
            if(kt!=0){
                 System.out.println("xoa data thanh cong");
            }
            else System.out.println("xoa du lieu khong thanh cong");
            ps.close();
            kn.close();
        } catch (SQLException e) {
            System.out.println("loi "+e.getMessage());
        }    
      }
      public void UpdatedsTB(int maTB,String tenTB,String xuatxuTB,int namsx ){
          kn=knoi.ketnoi();
          String sql="update dsthietbi set tentb = ? , xuatxu= ? , namsx=?  where matb = ?";
          try {
              ps=kn.prepareStatement(sql);
              ps.setString(1, tenTB);
              ps.setString(2, xuatxuTB);
              ps.setInt(3, namsx);
              ps.setInt(4, maTB);
              //thuc thi sql
              int kt =ps.executeUpdate();
              if(kt!=0){
                 System.out.println("update data thanh cong");
            }
            else System.out.println("update du lieu khong thanh cong");
            ps.close();
            kn.close();
             
          } catch (SQLException e) {
              System.out.println("loi "+e.getMessage());
          }
        }
      
    
}
