/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import controller.GiaoTiep;
import java.io.Serializable;

/**
 *
 * @author cuong
 */
public class QLTB implements Serializable,GiaoTiep{
    
    private TB t;
    private Phong p;
    private int soluong;
    private String trangthai;

    public TB getT() {
        return t;
    }

    public void setT(TB t) {
        this.t = t;
    }

    public Phong getP() {
        return p;
    }

    public void setP(Phong p) {
        this.p = p;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

   
    @Override
    public Object[] toObject(){
    return new Object[]{
        this.getP().getMaphong(),this.getP().getTenphong(),this.getT().getID(),this.getT().getTen(),this.getSoluong(),this.getTrangthai()
    };
    
}
    
}
