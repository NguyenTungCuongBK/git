/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import controller.GiaoTiep;
import java.io.Serializable;


/**
 *
 * @author cuong
 */
public class TB  implements Serializable,GiaoTiep{
    private int ID,namSX;
    private String ten,xuatxu;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getNamSX() {
        return namSX;
    }

    public void setNamSX(int namSX) {
        this.namSX = namSX;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getXuatxu() {
        return xuatxu;
    }

    public void setXuatxu(String xuatxu) {
        this.xuatxu = xuatxu;
    }

    @Override
    public Object[] toObject() {
       
            return new Object[]{
                this.getID(),this.getTen(),this.getXuatxu(),this.getNamSX()
            };
        }
    }

    

