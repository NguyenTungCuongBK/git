/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author cuong
 */
public class KetNoiDB {

    //thuc hien khoi tao mot doi tuong ket noi 
    Connection kn = null;
    String url = "jdbc:mysql://localhost/qlthietbi";//khai bao duong dan den csdl "jdbc:mysql://localhost/csdl-ai"
    String username = "root"; //tao tai khoan
    String password = "mysql";//mat khau mysql

    public Connection ketnoi() {
        try {
            //b2 load driver
            Class.forName("com.mysql.jdbc.Driver");
            kn = DriverManager.getConnection(url, username, password);
            //kn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("load driver khong thanh cong");

        } catch (SQLException e) {
            System.out.println("loi1" + e.getMessage());
        }
        return kn;
    }

}
