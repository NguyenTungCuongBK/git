/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import controller.GiaoTiep;
import java.io.Serializable;



/**
 *
 * @author cuong
 */
public class Phong implements Serializable,GiaoTiep {
    private int maphong;
    private String tenphong;

    public int getMaphong() {
        return maphong;
    }

    public void setMaphong(int maphong) {
        this.maphong = maphong;
    }

   

    public String getTenphong() {
        return tenphong;
    }

    public void setTenphong(String tenphong) {
        this.tenphong = tenphong;
    }
    @Override
    public Object [] toObject(){
        return new Object[]{
              this.getMaphong(),this.getTenphong()
        };
    }
    
    
    
}
